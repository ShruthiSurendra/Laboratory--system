package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.repository.PatientRepository;

@Component("ps")
public class PatientService {
	@Autowired
	PatientRepository patientRepo;
	public Patient create(Patient pt)
	{
		return patientRepo.save(pt);
	}
	public List<Patient> read()
	{
		return patientRepo.findAll();
	}
	public Patient read(String pid)
	{
		return patientRepo.findById(pid).get();
	}
	public Patient update(Patient Patient)
	{
		return patientRepo.save(Patient);
	}
	public void delete(String pid)
	{
		patientRepo.delete(read(pid));
	}
	

}

package com.mphasis.laboratory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaboratoryPatientApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaboratoryPatientApplication.class, args);
	}

}

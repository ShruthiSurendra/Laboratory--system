package com.mphasis.laboratory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratoryPatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
